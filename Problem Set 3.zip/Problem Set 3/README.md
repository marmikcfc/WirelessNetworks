# Problem Set - 3

Part 3
=============
`binToTxt.py` converts the binary files created as the output of file sink block of Gnuradio to Text files.

`avgBER.py` calculates the BER and plots the graph.

Pleach change the path to binary and Text Files in both the files.