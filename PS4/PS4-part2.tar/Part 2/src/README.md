# [PS -4](http://wireless-ps-4.appspot.com/)
src directory
============
Consists of all the code.

Running
============

Upload the sketch to MT7688 and the python file to OpenWRT

Running the Web App 
============
  * Create an account at Google App Engine Console
  * Create an app
  * Put your app ID in `` app.yaml `` file
  * Upload the project to GAE
  * Change the endpoint URL in `` transmitToCloud.py ``
  * Go to the URL
